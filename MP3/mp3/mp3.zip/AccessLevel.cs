﻿namespace MP03;

public enum AccessLevel
{
    Zero,
    One,
    Two,
    Three
}