namespace MP03.Overlapping;

public enum LinkType
{
    Bomber,
    FighterJet
}